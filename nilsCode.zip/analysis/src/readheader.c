#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pvp.h"

int main(int argc, char **argv)
{
    struct pvp_file file;
    FILE *fp = NULL;

    if (argc != 2) {
        printf("Usage: ./readpvp <file.pvp>\n");
        exit(EXIT_FAILURE);
    }

    if ((fp = fopen(argv[1], "r")) == NULL) {
        printf("Failed to open \"%s\"\n", argv[1]);
        exit(EXIT_FAILURE);
    }

    read_pvp_file(fp, &file);
    print_header(file.header);
    return 0;
}
