#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "pvp.h"

void read_header(FILE *fp, struct pvp_header *header, struct pvp_header_extended *extended);
void pvp_parse_nonspiking(struct pvp_file *file);
void pvp_parse_sparse(struct pvp_file *file);
void pvp_parse_weight(struct pvp_file *file);

void read_header(FILE *fp, struct pvp_header *header, struct pvp_header_extended *extended)
{
    assert(fp);
    size_t nread = fread((void *) header, 1, sizeof(struct pvp_header), fp);
    if (nread != sizeof(struct pvp_header)) {
        printf("Could not read header (read in %ld bytes; expected %ld bytes)\n",
                nread, sizeof(struct pvp_header));
        fclose(fp);
        exit(EXIT_FAILURE);
    }
    if (header->numparams == 26) {
        nread = fread((void *) extended, 1, sizeof(struct pvp_header_extended), fp);
        if (nread != sizeof(struct pvp_header_extended)) {
            printf("Could not read extended header (read in %ld bytes; expected %ld bytes)\n",
                    nread, sizeof(struct pvp_header_extended));
            fclose(fp);
            exit(EXIT_FAILURE);
        }
    } else if (header->numparams != 20) {
        printf("Invalid header (numparams = %d)\n", header->numparams);
        fclose(fp);
        exit(EXIT_FAILURE);
    }
}

void print_header(struct pvp_header header)
{
#define PRINT(field, format) printf(#field " = " #format "\n", header.field)
    PRINT(headersize, %d);
    PRINT(numparams, %d);
    printf("filetype = ");
    switch(header.filetype) {
        case PVP_FILE_TYPE                 : printf("PVP_FILE_TYPE                 \n"); break;
        case PVP_ACT_FILE_TYPE             : printf("PVP_ACT_FILE_TYPE             \n"); break;
        case PVP_WGT_FILE_TYPE             : printf("PVP_WGT_FILE_TYPE             \n"); break;
        case PVP_NONSPIKING_ACT_FILE_TYPE  : printf("PVP_NONSPIKING_ACT_FILE_TYPE  \n"); break;
        case PVP_KERNEL_FILE_TYPE          : printf("PVP_KERNEL_FILE_TYPE          \n"); break;
        case PVP_ACT_SPARSEVALUES_FILE_TYPE: printf("PVP_ACT_SPARSEVALUES_FILE_TYPE\n"); break;
    }
    PRINT(nx, %d);
    PRINT(ny, %d);
    PRINT(nf, %d);
    PRINT(numrecords, %d);
    PRINT(recordsize, %d);
    PRINT(datasize, %d);
    PRINT(datatype, %d);
    PRINT(nxprocs, %d);
    PRINT(nyprocs, %d);
    PRINT(nxGlobal, %d);
    PRINT(nyGlobal, %d);
    PRINT(kx0, %d);
    PRINT(ky0, %d);
    PRINT(nbatch, %d);
    PRINT(nbands, %d);
    PRINT(time, %f);
#undef PRINT
}

int read_pvp_file(FILE *fp, struct pvp_file *pvp_file)
{
    read_header(fp, &(pvp_file->header), &(pvp_file->header_extended));
    
    size_t cur = ftell(fp);
    fseek(fp, 0, SEEK_END);
    size_t size = ftell(fp) - cur;
    fseek(fp, cur, SEEK_SET);

    pvp_file->data = malloc(size);
    assert(pvp_file->data);
    size_t nread = fread(pvp_file->data, 1, size, fp);
    if (nread != size) {
        printf("Could not read file (read in %ld bytes; expected %ld bytes)\n",
                nread, size);
        fclose(fp);
        exit(EXIT_FAILURE);
    } 
    fclose(fp);
    switch (pvp_file->header.filetype) {
    case PVP_FILE_TYPE                   :
    case PVP_ACT_FILE_TYPE               :
        printf("Filetype (%d) not implemented yet\n", pvp_file->header.filetype);
        break;
    case PVP_WGT_FILE_TYPE               :
    case PVP_KERNEL_FILE_TYPE            :
        pvp_parse_weight(pvp_file);
        break;
    case PVP_NONSPIKING_ACT_FILE_TYPE    :
        pvp_parse_nonspiking(pvp_file);
        break;
    case PVP_ACT_SPARSEVALUES_FILE_TYPE  :
        pvp_parse_sparse(pvp_file);
        break;
    default:
        printf("Unknown file type\n");
        return -1;
    }
    return pvp_file->header.filetype;
}

void pvp_parse_nonspiking(struct pvp_file *file)
{
    assert(file->header.datatype == PV_FLOAT_TYPE);
    file->nonspiking = malloc(sizeof(struct pvp_nonspiking_activity) * file->header.nbands);
    int i;
    int frame_size = 8 + file->header.recordsize * sizeof(float);
    #pragma omp parallel for schedule(static)
    for (i = 0; i < file->header.nbands; i++) {
        file->nonspiking[i].time = *(double *) (file->data + i*frame_size);
        file->nonspiking[i].data = (float *) (file->data + i*frame_size + 8);
    }
}

void pvp_parse_sparse(struct pvp_file *file)
{
    void * tmp = file->data;
    file->sparsevalues = malloc(sizeof(struct pvp_sparsevalues) * file->header.nbands);
    int i;
    for (i = 0; i < file->header.nbands; i++) {
        file->sparsevalues[i].time = *(double *) tmp;
        tmp += 8;
        file->sparsevalues[i].numActive = *(uint32_t *) tmp;
        tmp += 4;
        file->sparsevalues[i].data = tmp;
        tmp += file->sparsevalues[i].numActive * sizeof(struct pvp_sparsevalues_entry);
    }
}

void pvp_parse_weight(struct pvp_file *file)
{
    void * tmp = file->data;

    int num_arbor = file->header.nbands;
    int num_proc = file->header.nxprocs * file->header.nyprocs;
    int num_patch = file->header_extended.numpatches;

    int patch_size = file->header_extended.nxp * file->header_extended.nyp * file->header_extended.nfp * sizeof(float);

    printf("num arbor  = %d\n", num_arbor);
    printf("num proc   = %d\n", num_proc);
    printf("num patch  = %d\n", num_patch);
    printf("patch size = %d\n", patch_size);


    int i,j,k;
    for (i = 0; i < num_arbor; i++) { // For each arbor
        for (j = 0; j < num_proc; j++) { // For each proc
            for (k = 0; k < num_patch; k++) { // For each patch
                uint16_t * nx = (uint16_t *) tmp;
                uint16_t * ny = (uint16_t *) (tmp + 2);
                uint32_t * offset = (uint32_t *) (tmp + 4);
                uint32_t * time = tmp;
                float * data = tmp + 8;
                tmp += 8 + patch_size;


            }
        }
    }
}
