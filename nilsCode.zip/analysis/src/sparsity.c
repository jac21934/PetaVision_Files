#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "pvp.h"

int main(int argc, char **argv)
{
    struct pvp_file file;
    FILE *fp = NULL;

    if (argc != 2) {
        printf("Usage: ./readpvp <file.pvp>\n");
        exit(EXIT_FAILURE);
    }

    if ((fp = fopen(argv[1], "r")) == NULL) {
        printf("Failed to open \"%s\"\n", argv[1]);
        exit(EXIT_FAILURE);
    }

    if (read_pvp_file(fp, &file) != PVP_ACT_SPARSEVALUES_FILE_TYPE) {
        printf("Error: Not a sparse activity file type\n");
        exit(EXIT_FAILURE);
    }

    long total_active = 0;
    int i;
    printf("nbands = %d\n", file.header.nbands);
    for (i = 0; i < file.header.nbands; i++) {
        total_active += file.sparsevalues[i].numActive;
        printf("%d: %d\n", i, file.sparsevalues[i].numActive);
    }

    double layer_size = file.header.nx * file.header.ny * file.header.nf;
    double avg_sparsity = ((double) total_active / (double) file.header.nbands) / layer_size;

    double variance = 0;
    for (i = 0; i < file.header.nbands; i++) {
        variance += pow((file.sparsevalues[i].numActive / layer_size) - avg_sparsity, 2);
    }
    variance /= file.header.nbands;

    
    printf("%f\t%f\t", 100*avg_sparsity, 100*sqrt(variance));

    return 0;
}
