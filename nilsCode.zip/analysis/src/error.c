#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "pvp.h"

struct pvp_file open_pvp(char * filename)
{
    FILE *fp;
    struct pvp_file file;
    if ((fp = fopen(filename, "r")) == NULL) {
        printf("Failed to open \"%s\"\n", filename);
        exit(EXIT_FAILURE);
    } 

    if (read_pvp_file(fp, &file) != PVP_NONSPIKING_ACT_FILE_TYPE) {
        printf("Error: %s is not a nonspiking activity file type\n", filename);
        exit(EXIT_FAILURE);
    }

    return file;
}

int main(int argc, char **argv)
{
    int i, j;
    struct pvp_file input;
    struct pvp_file error;

    if (argc != 3) {
        printf("Usage: ./readpvp <Input.pvp> <DenoiseError.pvp>\n");
        exit(EXIT_FAILURE);
    } 

    input = open_pvp(argv[1]);
    error = open_pvp(argv[2]);

    int num_images = input.header.nbands;

    // Store L2 reconstruction error for standard deviation calculation
    double * l2_norm = malloc(sizeof(double) * num_images);

    // Compute the average normalized reconstruction error
    double l2_avg = 0;
    double l2_variance = 0;
    double l2_input;
    double l2_error;
    #pragma omp parallel private(l2_input, l2_error, i, j)
    {
        #pragma omp for
        for (i = 0; i < num_images; i++) {
            // Compute L2 norm of the input image and reconstruction error
            l2_input = 0;
            l2_error = 0;
            for (j = 0; j < input.header.recordsize; j++) {
                l2_input += pow(input.nonspiking[i].data[j], 2);
                l2_error += pow(error.nonspiking[i].data[j], 2);
            }
            l2_input = sqrt(l2_input);
            l2_error = sqrt(l2_error);

            // Normalize reconstruction error with the L2 norm of the input
            l2_norm[i] = l2_error/l2_input;
        }
        #pragma omp for reduction(+:l2_avg)
        for (i = 0; i < num_images; i++) {
            l2_avg += l2_norm[i];
        }

        #pragma omp master
        {
            l2_avg /= num_images;
        }
        
        // Compute the standard deviation of the reconstruction error
        #pragma omp barrier
        #pragma omp for reduction(+:l2_variance)
        for (i = 0; i < num_images; i++) {
            l2_variance += pow(l2_norm[i] - l2_avg, 2);
        }
    }
    l2_variance /= num_images;

    printf("%f\t%f", l2_avg, sqrt(l2_variance));
    
    free(l2_norm);
    return 0;
}
