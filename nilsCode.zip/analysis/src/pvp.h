#pragma once

#include <stdint.h>

// File types
#define PVP_FILE_TYPE                   1 // Deprecated
#define PVP_ACT_FILE_TYPE               2
#define PVP_WGT_FILE_TYPE               3
#define PVP_NONSPIKING_ACT_FILE_TYPE    4
#define PVP_KERNEL_FILE_TYPE            5
#define PVP_ACT_SPARSEVALUES_FILE_TYPE  6

// Data types
#define PV_BYTE_TYPE            1
#define PV_INT_TYPE             2
#define PV_FLOAT_TYPE           3
#define PV_SPARSEVALUES_TYPE    4

// Packed structure; 80 bytes
struct __attribute__((__packed__)) pvp_header {
    uint32_t headersize;
    uint32_t numparams;
    uint32_t filetype;
    uint32_t nx;
    uint32_t ny;
    uint32_t nf;
    uint32_t numrecords;
    uint32_t recordsize;
    uint32_t datasize;
    uint32_t datatype;
    uint32_t nxprocs;
    uint32_t nyprocs;
    uint32_t nxGlobal;
    uint32_t nyGlobal;
    uint32_t kx0;
    uint32_t ky0;
    uint32_t nbatch;
    uint32_t nbands;
    double   time;
};


struct __attribute__((__packed__)) pvp_header_extended {
    uint32_t nxp;
    uint32_t nyp;
    uint32_t nfp;
    float wMin;
    float wMax;
    uint32_t numpatches;
};

struct pvp_file {
    struct pvp_header header;
    struct pvp_header_extended header_extended;
    void * data;
    struct pvp_sparsevalues {
        float time;
        uint32_t numActive;
        struct pvp_sparsevalues_entry {
            uint32_t index;
            float activity;
        } * data;
    } * sparsevalues;
    struct pvp_nonspiking_activity {
        float time;
        float * data;
    } * nonspiking;
};

int read_pvp_file(FILE *fp, struct pvp_file *pvp_file);
void print_header(struct pvp_header header);
